$(document).ready(function(){
	    $(".nut-menu").click(function(){
	        $(".xo-down").slideToggle();
	    });
	});

$(document).ready(function(){
	    $(".us,.use").click(function(){
	        $(".conn").slideToggle();
	    });
	});




