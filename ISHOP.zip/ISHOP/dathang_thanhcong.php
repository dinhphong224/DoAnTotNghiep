<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
<style>
	
	.dhtc{
		max-width: 500px;
		margin: 0px auto;
		font-weight: bold;
		color:blue;
		font: 20pt "Myriad Pro Condensed";
		text-align: center;
		padding: 30px 0px;
	}
</style>
<div class="main" style='overflow: hidden;'>
	<div class="container">
	<div class="complete">
	<img src="img/complete.png" alt="" style='display: block;margin-left: auto;margin-right: auto;margin-top:30px;'>
		<p class='dhtc'>CHÚC MỪNG QUÝ KHÁCH ĐÃ ĐẶT HÀNG THÀNH CÔNG.CHÚNG TÔI SẼ LIÊN HỆ VỚI BẠN TRONG VÒNG 30 PHÚT.THANK YOU VERY MUCH..!!!</p>
		</div>
	</div>
</div>