<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Bảo Hành</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
	<link rel="stylesheet" href="css/baohanh.css">
</head>
<body>
<div class="main">
	<div class="baohanh">
		<div class="container">
		<h3 class="tdbh"><span>TRA CỨU</span> SỬA CHỮA BẢO HÀNH</h3>
			<div class="form-bh">
			<div class="row">
				<form action="" method='get'>
					<div class="form-group">
						<input type="text" class='form-control' placeholder="NHẬP MÃ SỬA  CHỮA BẢO HÀNH" id='nhapbh'>
					</div>
					<div class="nut-tracuu">
						<input type="submit" value='TRA CỨU' id='tracuu'>
					</div>
				</form>
			</div>
			</div>
		</div>
	</div>
	</div>
</body>
</html>